const express = require('express');

const router = express.Router();
router.get('/',(req,res)=>{
    res.send('Home');
});

module.exports = router;

const trains = require('../MODELS/search.model.schema')